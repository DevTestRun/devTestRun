import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
	selector : 'template-form',
	templateUrl : 'app/view/templateForm.component.html',
	styleUrls : [`app/styles/templateForm.component.css`]
})
export class TemplateFormComponent{
	submitForm(loginForm: NgForm){
		console.log(loginForm.value);
	}
}