import { Component } from '@angular/core';

@Component({
	selector : 'template-form',
	templateUrl : 'app/view/templateForm.component.html',
	styleUrls : [`app/styles/templateForm.component.css`]
})
export class TemplateFormComponent{
	submitForm(loginForm){
		console.log(loginForm.value);
	}
}