import { LazyComponent } from './lazy.component';
import { Routes } from '@angular/router';

export const LAZY_ROUTES : Routes = [
	{ path : '', component : LazyComponent}
]

