"use strict";
var lazy_component_1 = require("./lazy.component");
exports.LAZY_ROUTES = [
    { path: '', component: lazy_component_1.LazyComponent }
];
//# sourceMappingURL=lazy.routes.js.map