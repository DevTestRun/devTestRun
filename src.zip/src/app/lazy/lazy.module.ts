import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LazyComponent } from './lazy.component'; 
import { LAZY_ROUTES } from './lazy.routes'; 
import { RouterModule } from '@angular/router'; 

@NgModule({
	imports : [ CommonModule, RouterModule.forChild(LAZY_ROUTES) ],
	declarations : [LazyComponent],

})
export class LazyModule{}
