import { Component } from '@angular/core';
import { SharedService } from '../shared/shared.service'; 

@Component({
  template: `<h1>Lazy Component Loaded Successfully!!!</h1>

  <div class="container">
	<button class="btn btn-default" (click)="increase()">Increase Counter</button>
	<h2>Share Service Counter in Lazy Component : {{sharedService.counter}}</h2>
</div>


  `,
})
export class LazyComponent  {

	constructor(private sharedService : SharedService){}

	increase(){
		this.sharedService.counter++;
	}

 }


