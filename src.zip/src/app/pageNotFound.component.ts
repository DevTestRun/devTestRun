import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  template: `<h1>No Page Here. </h1>
  	<button class="badge" (click)="goToHome()"> Go To Home</button>

  `,
})
export class PageNotFoundComponent  {

	constructor( private router : Router){}

	goToHome(){
		this.router.navigate(['/'])
	}
}


