"use strict";
var user_component_1 = require("./user.component");
var loginForm_component_1 = require("./loginForm.component");
var modelForm_component_1 = require("./modelForm.component");
var about_component_1 = require("./about.component");
var contact_component_1 = require("./contact.component");
var product_component_1 = require("./product.component");
var pageNotFound_component_1 = require("./pageNotFound.component");
var overview_component_1 = require("./overview.component");
var spec_component_1 = require("./spec.component");
var logingaurd_service_1 = require("./logingaurd.service");
exports.APP_ROUTES = [
    { path: '', redirectTo: 'user', pathMatch: 'full' },
    { path: 'user', component: user_component_1.UserComponent },
    { path: 'about', component: about_component_1.AboutComponent },
    { path: 'product/:id', component: product_component_1.ProductComponent,
        children: [
            { path: "", redirectTo: 'overview', pathMatch: 'full' },
            { path: "overview", component: overview_component_1.OverviewComponent },
            { path: "spec", component: spec_component_1.SpecComponent }
        ] },
    { path: 'contact', component: contact_component_1.ContactComponent },
    { path: 'templateform', component: loginForm_component_1.TemplateFormComponent,
        canActivate: [logingaurd_service_1.LoginGaurd] },
    { path: 'modelform', component: modelForm_component_1.ModelFormComponent },
    { path: 'lazylink', loadChildren: 'app/lazy/lazy.module#LazyModule' },
    { path: '**', component: pageNotFound_component_1.PageNotFoundComponent }
];
//# sourceMappingURL=app.routes.js.map