import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1>Hello {{name}}</h1>
  	<user-comp>
  		<header>Header Information {{name}}</header>
  		<section>Section Information </section>
  		<footer>Footer Information</footer>
  	</user-comp>
  `,
})
export class AppComponent  { name = 'Angular'; }


