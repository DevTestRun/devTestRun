import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { SharedModule } from './shared/shared.module';


import { AppComponent }  from './app.component';
import { UserComponent } from './user.component';
import { DoubleMePipe } from './doubleMe.pipe';
import { TemplateFormComponent } from './loginForm.component';
import { ModelFormComponent } from './modelForm.component';
import { AboutComponent } from './about.component';
import { ContactComponent } from './contact.component';
import { ProductComponent } from './product.component';
import { PageNotFoundComponent } from './pageNotFound.component';
import { OverviewComponent } from './overview.component';
import { SpecComponent } from './spec.component';

import { UserService } from './user.service';
import { LoginGaurd } from './logingaurd.service'; 

import { APP_ROUTES } from './app.routes';

@NgModule({
  imports:      [ BrowserModule, FormsModule, 
  					ReactiveFormsModule, HttpModule,
  					RouterModule.forRoot(APP_ROUTES), SharedModule ],
  declarations: [ AppComponent, UserComponent, 
  					DoubleMePipe, TemplateFormComponent, 
  					ModelFormComponent, AboutComponent, 
  					ContactComponent, ProductComponent,
  					OverviewComponent, SpecComponent,
  					PageNotFoundComponent],
  providers	:	[ UserService, LoginGaurd ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
