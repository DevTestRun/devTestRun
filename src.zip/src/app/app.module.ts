import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';


import { AppComponent }  from './app.component';
import { UserComponent } from './user.component';
import { DoubleMePipe } from './doubleMe.pipe';
import { TemplateFormComponent } from './loginForm.component';
import { ModelFormComponent } from './modelForm.component';

import { UserService } from './user.service';

@NgModule({
  imports:      [ BrowserModule, FormsModule, 
  					ReactiveFormsModule, HttpModule ],
  declarations: [ AppComponent, UserComponent, 
  					DoubleMePipe, TemplateFormComponent, 
  					ModelFormComponent ],
  providers	:	[ UserService ],
  bootstrap:    [ AppComponent, ModelFormComponent  ]
})
export class AppModule { }
