"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
//import { USER_DATA } from './mocks';
var user_service_1 = require("./user.service");
var shared_service_1 = require("./shared/shared.service");
var UserComponent = (function () {
    function UserComponent(userService, sharedService) {
        this.userService = userService;
        this.sharedService = sharedService;
        this.myClass = { 'feature': true, 'big': false, 'dark': false };
        if (true) {
            this.myClass.big = true;
        }
    }
    UserComponent.prototype.increase = function () {
        this.sharedService.counter++;
    };
    UserComponent.prototype.moreInfo = function (user) {
        alert(user.firstName + " is working with " + user.company);
        //console.log(this.time);
    };
    UserComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userService.getUserData()
            .subscribe(function (people) { return _this.users = people; });
    };
    return UserComponent;
}());
UserComponent = __decorate([
    core_1.Component({
        selector: 'user-comp',
        templateUrl: "app/view/user.component.html",
        styleUrls: ["app/styles/user.component.css"]
    }),
    __metadata("design:paramtypes", [user_service_1.UserService, shared_service_1.SharedService])
], UserComponent);
exports.UserComponent = UserComponent;
//# sourceMappingURL=user.component.js.map