import { Component } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
	selector : 'model-form',
	templateUrl : 'app/view/modelForm.component.html',
	styleUrls : [`app/styles/templateForm.component.css`]
})
export class ModelFormComponent{

	myValidation(input : FormControl){
		let hasAtSign = input.value.indexOf('@')>=0;
		return hasAtSign ? null : {needAtSign : true}
	}

	username = new FormControl('enter username...', [
		Validators.required,
		Validators.minLength(5),
		this.myValidation
		]);
	password = new FormControl('', [
		Validators.required
		
		]);

	loginForm : FormGroup;

	constructor(private fb : FormBuilder){
		this.loginForm = this.fb.group({
			username : this.username,
			password : this.password
		})
	}

	submitForm(){
		console.log(this.loginForm);
	}
}
