import { Component } from '@angular/core';

@Component({
  template: `<h1>About Template Loaded Successfully!!!</h1>`,
})
export class AboutComponent  {}


