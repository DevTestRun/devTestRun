import { Component } from '@angular/core';
import { User } from './user';
//import { USER_DATA } from './mocks';
import { UserService } from './user.service';
import { SharedService } from './shared/shared.service';

@Component({
	selector : 'user-comp',
	templateUrl : `app/view/user.component.html`,
	styleUrls	:	[`app/styles/user.component.css`]
})
export class UserComponent{

	increase(){
		this.sharedService.counter++;
	}

	myClass = {'feature' : true, 'big' : false,'dark': false };

	constructor(private userService : UserService, private sharedService : SharedService){
		if(true){
			this.myClass.big = true;
		}
	}

	moreInfo(user : User){
		alert(user.firstName + " is working with " + user.company);
		//console.log(this.time);
	}


	users : User[];
	time : any;

	ngOnInit(){
		this.userService.getUserData()
			.subscribe(people => this.users = people);
		
	}

}