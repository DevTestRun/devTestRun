import { Component } from '@angular/core';

@Component({
  template: `<h1>Product Specification will be loaded here...</h1>`,
})
export class SpecComponent  {}


