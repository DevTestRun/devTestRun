import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router'; 

@Component({
  templateUrl: `app/view/product.component.html`,
})
export class ProductComponent  {
	id : number;
	constructor(private route : ActivatedRoute){
		this.route.params.subscribe(params=>{
			this.id = +params["id"]
		})
	}

}


