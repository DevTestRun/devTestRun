import { Injectable } from '@angular/core';

@Injectable()
export class SharedService {
	counter : number =0;
}