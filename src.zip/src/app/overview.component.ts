import { Component } from '@angular/core';

@Component({
  template: `<h1>Product Overview will be loaded here...</h1>`,
})
export class OverviewComponent  {}


