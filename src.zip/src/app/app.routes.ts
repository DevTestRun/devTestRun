import { Route } from '@angular/router';
import { UserComponent } from './user.component';
import { TemplateFormComponent } from './loginForm.component';
import { ModelFormComponent } from './modelForm.component';
import { AboutComponent } from './about.component';
import { ContactComponent } from './contact.component';
import { ProductComponent } from './product.component';
import { PageNotFoundComponent } from './pageNotFound.component';
import { OverviewComponent } from './overview.component';
import { SpecComponent } from './spec.component';
import { LoginGaurd } from './logingaurd.service';

export const APP_ROUTES : Route[] =[
	{ path : '', redirectTo : 'user', pathMatch : 'full'},	
	{ path : 'user', component : UserComponent},
	{ path : 'about', component : AboutComponent},
	{ path : 'product/:id', component : ProductComponent, 
		children : [
			{ path : "", redirectTo : 'overview', pathMatch : 'full'},
			{ path : "overview", component : OverviewComponent},
			{ path : "spec", component : SpecComponent}

		]},
	{ path : 'contact', component : ContactComponent},
	{ path : 'templateform', component : TemplateFormComponent, 
		canActivate : [LoginGaurd] },
	{ path : 'modelform', component : ModelFormComponent},
	
	{ path : 'lazylink', loadChildren : 'app/lazy/lazy.module#LazyModule'},
	{ path : '**', component : PageNotFoundComponent}
]